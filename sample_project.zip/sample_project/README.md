# Sample App
Demo for static scanner
