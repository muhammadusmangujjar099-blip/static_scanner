import os
import subprocess

# BAD: hardcoded secret
API_KEY = "sk_live_abc123xyz789secretkey"
DB_PASSWORD = "supersecret123"
AWS_SECRET_ACCESS_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

def run_cmd(user_input):
    # BAD: shell injection
    os.system("echo " + user_input)
    subprocess.call(user_input, shell=True)

def unsafe():
    # BAD
    eval(user_code)
    data = pickle.loads(untrusted)

# TODO: fix security
print("Hello")
